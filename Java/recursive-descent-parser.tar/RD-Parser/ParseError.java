public class ParseError extends Exception {
	public ParseError(String errorMsg) {
		super(errorMsg);
	}
}