package Assembler;

public class NEWLINE extends AssemblerCmd {

    public NEWLINE() {}
    public String toString() {
        return "";
    }
}
