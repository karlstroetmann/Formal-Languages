package Assembler;

public class MAIN extends AssemblerCmd {

    public MAIN() {}
    public String toString() {
        return ".method public static main([Ljava/lang/String;)V";
    }
}
