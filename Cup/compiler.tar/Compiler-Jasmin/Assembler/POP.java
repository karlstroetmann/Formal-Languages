package Assembler;

public class POP extends AssemblerCmd {

    public POP() {}
    public String toString() {
        return "pop";
    }
}
