package Assembler;

public class IMUL extends AssemblerCmd {

    public IMUL() {}
    public String toString() {
        return "imul";
    }
}
