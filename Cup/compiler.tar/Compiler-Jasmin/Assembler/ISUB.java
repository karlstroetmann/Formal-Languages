package Assembler;

public class ISUB extends AssemblerCmd {

    public ISUB() {}
    public String toString() {
        return "isub";
    }
}
