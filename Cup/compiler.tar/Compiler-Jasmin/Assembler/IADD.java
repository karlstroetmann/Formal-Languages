package Assembler;

public class IADD extends AssemblerCmd {

    public IADD() {}
    public String toString() {
        return "iadd";
    }
}
