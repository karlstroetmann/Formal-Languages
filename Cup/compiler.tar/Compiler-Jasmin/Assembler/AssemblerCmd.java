package Assembler;

/* This class is the mother of all assembler commands */
public abstract class AssemblerCmd {
    public abstract String toString();
}
