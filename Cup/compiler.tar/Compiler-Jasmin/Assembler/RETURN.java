package Assembler;

public class RETURN extends AssemblerCmd {

    public RETURN() {}
    public String toString() {
        return "return";
    }
}
