package Assembler;

public class END_METHOD extends AssemblerCmd {

    public END_METHOD() {}
    public String toString() {
        return ".end method";
    }
}
