package Assembler;

public class IRETURN extends AssemblerCmd {

    public IRETURN() {}
    public String toString() {
        return "ireturn";
    }
}
