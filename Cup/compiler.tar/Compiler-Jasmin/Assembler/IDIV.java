package Assembler;

public class IDIV extends AssemblerCmd {

    public IDIV() {}
    public String toString() {
        return "idiv";
    }
}
