package Assembler;

public class IAND extends AssemblerCmd {

    public IAND() {}
    public String toString() {
        return "iand";
    }
}
