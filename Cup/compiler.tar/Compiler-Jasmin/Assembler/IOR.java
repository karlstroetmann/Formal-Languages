package Assembler;

public class IOR extends AssemblerCmd {

    public IOR() {}
    public String toString() {
        return "ior";
    }
}
