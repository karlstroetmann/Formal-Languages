public abstract class BoolExpr {
	public abstract Boolean eval(Environment e) throws ReturnException;
}