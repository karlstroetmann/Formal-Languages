public abstract class Statement {
	public abstract void execute();
}
