public abstract class BoolExpr {
	public abstract Boolean eval();
}