public abstract class Expr {
	public abstract Expr diff(Variable x);
}


