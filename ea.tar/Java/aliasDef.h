#define State         Integer
#define StateSet      Set<State>
#define StateChar     Pair<State, Character>
#define TransitionMap Map<StateChar, State>
