public class Triple<A, B, C> {
	A mA;
	B mB;
	C mC;
	
	public Triple(A a, B b, C c) {
		mA = a;
		mB = b;
		mC = c;
	}
}
